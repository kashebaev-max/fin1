// Netlify Function: AI Жанара (расширенная)
// POST /.netlify/functions/ai-zhanara
//
// Ожидает: { messages: [{role, content}], context: BusinessContext, mode?: 'chat'|'insights' }
// Возвращает: { reply: string } или { insights: [...] }

const ANTHROPIC_API = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-5"; // последняя стабильная Sonnet
const MAX_TOKENS_CHAT = 1500;
const MAX_TOKENS_INSIGHTS = 2000;

const SYSTEM_PROMPT_CHAT = `Ты — Жанара, AI-консультант по бухгалтерии и налогообложению Республики Казахстан в системе Finstat.kz. Ты эксперт в Налоговом кодексе РК 2026 года, бухгалтерском учёте по НСФО, кадровом делопроизводстве по ТК РК.

ТВОЯ РОЛЬ:
- Активный помощник, не пассивный справочник
- Видишь полное состояние бизнеса пользователя в реальном времени
- Даёшь точные, действенные советы на основе цифр пользователя, а не общих фраз
- При обращении используй имя пользователя
- Если видишь проблему — поднимай её, даже если не спрашивают

СТИЛЬ:
- Кратко, по делу, без воды
- Цифры — со ссылкой на конкретные суммы из контекста
- Когда уместно — конкретные шаги: "Зайди в [модуль], сделай [действие]"
- Не повторяй данные контекста без необходимости — пользователь их и так видит на экране

ЗНАНИЯ НК РК 2026:
- НДС: 16% (льготные 5%/10%), порог регистрации 10 000 МРП = 43 250 000 ₸
- ИПН: 10% до 8500 МРП/год, 15% свыше; стандартный вычет 14 МРП = 60 550 ₸
- КПН: 20% базовая, 25% банки, 3% с/х, 5% соцсфера
- ОПВ: 10% работник | ОПВР: 3.5% работодатель
- ВОСМС: 2% | ООСМС: 3% | СО: 5% | СН: 6%
- МРП 2026: 4 325 ₸ | МЗП 2026: 85 000 ₸
- Упрощёнка: 4% (ИПН + СН пополам)

СРОКИ ФНО:
- Квартальные (200, 300): до 15 числа второго месяца после квартала
- Ежемесячные (910): до 15 числа следующего месяца
- Годовая (100): до 31 марта следующего года

БУХУЧЁТ (НСФО РК):
- Счета 1010, 1030 — деньги (актив)
- 1210 — дебиторка | 3310 — кредиторка
- 1310-1330 — запасы
- 6010 — выручка | 7010 — себестоимость | 7210 — адм.расходы
- 5510 — нераспределённая прибыль

ВАЖНО:
- Если пользователь спрашивает о действии — указывай точный модуль в системе
- Если в контексте видишь проблему (просрочки, низкие остатки, приближающиеся ФНО) — упомяни её, даже если спрашивают о другом
- Не выдумывай цифры — используй только те, что в контексте`;

const SYSTEM_PROMPT_INSIGHTS = `Ты — Жанара, AI-консультант системы Finstat.kz. Твоя задача — проанализировать состояние бизнеса и сгенерировать список инсайтов: проблем, рисков, возможностей, рекомендаций.

ВЕРНИ ВАЛИДНЫЙ JSON в формате:
{
  "insights": [
    {
      "category": "tax_deadline|cashflow|overdue|low_stock|expiring_batches|unposted_docs|salary_due|recommendation|anomaly|opportunity|compliance|general",
      "severity": "critical|warning|info|success",
      "title": "Короткий заголовок (до 60 знаков)",
      "message": "Подробное объяснение и рекомендация (до 200 знаков)",
      "actionLabel": "Текст кнопки действия (опц., до 30 знаков)",
      "actionUrl": "/dashboard/нужный-модуль (опц.)",
      "relatedModule": "ключ модуля (опц.)"
    }
  ]
}

ПРАВИЛА:
- Только реальные проблемы из данных контекста, не выдумывай
- Минимум 3, максимум 8 инсайтов — самых важных
- Severity: critical = немедленно (просроченные налоги, ФНО через 1-2 дня); warning = в ближайшие дни; info = к сведению; success = всё хорошо (1 такой можно)
- Если бизнес здоров — пиши success-инсайт
- Никакого текста вне JSON. Никаких markdown-блоков. ТОЛЬКО валидный JSON.
- Заголовки цепляющие, не "Внимание:" а "До ФНО 200 осталось 3 дня"
- В messages указывай конкретные суммы из контекста

ПОЛЕЗНЫЕ URL:
/dashboard/reports — отчёты ФНО
/dashboard/financial-statements — баланс и ОПУ
/dashboard/turnover — ОСВ
/dashboard/batches — партионный учёт (для сроков годности)
/dashboard/nomenclature — номенклатура (для остатков)
/dashboard/recurring — регулярные платежи
/dashboard/orders — заказы
/dashboard/hr — кадры и ЗП
/dashboard/vacations — отпуска
/dashboard/scheduled-tasks — регламентные задания`;

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
}

exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders(), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: corsHeaders(), body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: "ANTHROPIC_API_KEY not set" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { messages = [], context = null, mode = "chat", contextText = "" } = body;
  const isInsights = mode === "insights";

  // Системный промпт + контекст
  const systemBase = isInsights ? SYSTEM_PROMPT_INSIGHTS : SYSTEM_PROMPT_CHAT;
  const fullSystem = contextText
    ? `${systemBase}\n\n=== ТЕКУЩЕЕ СОСТОЯНИЕ БИЗНЕСА ПОЛЬЗОВАТЕЛЯ ===\n${contextText}\n=== КОНЕЦ КОНТЕКСТА ===`
    : systemBase;

  try {
    const claudeRes = await fetch(ANTHROPIC_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: isInsights ? MAX_TOKENS_INSIGHTS : MAX_TOKENS_CHAT,
        system: fullSystem,
        messages: isInsights
          ? [{ role: "user", content: "Проанализируй контекст и верни инсайты в JSON формате." }]
          : messages,
      }),
    });

    if (!claudeRes.ok) {
      const errText = await claudeRes.text();
      return {
        statusCode: claudeRes.status,
        headers: corsHeaders(),
        body: JSON.stringify({ error: `Claude API error: ${errText}` }),
      };
    }

    const data = await claudeRes.json();
    const reply = data.content?.[0]?.text || "";

    if (isInsights) {
      // Парсим JSON из ответа
      try {
        // Убираем возможные markdown-обёртки
        const cleaned = reply.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
        const parsed = JSON.parse(cleaned);
        return {
          statusCode: 200,
          headers: { ...corsHeaders(), "Content-Type": "application/json" },
          body: JSON.stringify({ insights: parsed.insights || [] }),
        };
      } catch (parseErr) {
        return {
          statusCode: 200,
          headers: { ...corsHeaders(), "Content-Type": "application/json" },
          body: JSON.stringify({ insights: [], error: "Failed to parse AI response", raw: reply }),
        };
      }
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify({ reply }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: JSON.stringify({ error: String(err) }),
    };
  }
};
