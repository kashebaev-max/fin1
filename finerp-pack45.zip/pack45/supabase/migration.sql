-- ═══════════════════════════════════════════
-- Pack 45: AI Жанара — фундамент
-- ═══════════════════════════════════════════

-- Сгенерированные инсайты (кэш, чтобы не звать AI на каждом обновлении)
CREATE TABLE IF NOT EXISTS ai_insights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Категория инсайта (для группировки и иконок)
  category TEXT NOT NULL CHECK (category IN (
    'tax_deadline', 'cashflow', 'overdue', 'low_stock',
    'expiring_batches', 'unposted_docs', 'salary_due',
    'recommendation', 'anomaly', 'opportunity', 'compliance', 'general'
  )),
  
  -- Уровень важности
  severity TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('critical', 'warning', 'info', 'success')),
  
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  
  -- Что делать (опционально)
  action_label TEXT,
  action_url TEXT,
  
  -- Метаданные для фильтрации
  related_module TEXT,
  related_entity_id UUID,
  
  is_dismissed BOOLEAN DEFAULT false,
  is_read BOOLEAN DEFAULT false,
  
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_aii_user ON ai_insights(user_id);
CREATE INDEX IF NOT EXISTS idx_aii_dismissed ON ai_insights(is_dismissed);
CREATE INDEX IF NOT EXISTS idx_aii_severity ON ai_insights(severity);
ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "aii_all" ON ai_insights;
CREATE POLICY "aii_all" ON ai_insights FOR ALL USING (auth.uid() = user_id);

-- История разговоров с Жанарой (для контекста между сессиями)
CREATE TABLE IF NOT EXISTS ai_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  session_id TEXT NOT NULL, -- группировка по сессии
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  
  -- Контекст в момент сообщения (что Жанара "видела")
  business_context JSONB DEFAULT '{}',
  current_module TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_aic_user ON ai_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_aic_session ON ai_conversations(session_id);
CREATE INDEX IF NOT EXISTS idx_aic_created ON ai_conversations(created_at);
ALTER TABLE ai_conversations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "aic_all" ON ai_conversations;
CREATE POLICY "aic_all" ON ai_conversations FOR ALL USING (auth.uid() = user_id);

-- Сводка контекста бизнеса (последний снепшот для быстрого доступа)
CREATE TABLE IF NOT EXISTS ai_business_snapshot (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  
  -- Финансовое состояние
  cash_total NUMERIC(15,2) DEFAULT 0,
  bank_total NUMERIC(15,2) DEFAULT 0,
  
  -- Дебиторка/кредиторка
  receivables NUMERIC(15,2) DEFAULT 0,
  payables NUMERIC(15,2) DEFAULT 0,
  
  -- Налоги к уплате
  vat_due NUMERIC(15,2) DEFAULT 0,
  ipn_due NUMERIC(15,2) DEFAULT 0,
  cit_due NUMERIC(15,2) DEFAULT 0,
  
  -- Запасы
  stock_value NUMERIC(15,2) DEFAULT 0,
  low_stock_count INTEGER DEFAULT 0,
  expiring_batches_count INTEGER DEFAULT 0,
  expired_batches_count INTEGER DEFAULT 0,
  
  -- Доходы/расходы за месяц
  revenue_mtd NUMERIC(15,2) DEFAULT 0,
  expenses_mtd NUMERIC(15,2) DEFAULT 0,
  
  -- Кадры
  employees_count INTEGER DEFAULT 0,
  payroll_total NUMERIC(15,2) DEFAULT 0,
  
  -- Документы
  draft_docs_count INTEGER DEFAULT 0,
  overdue_payments_count INTEGER DEFAULT 0,
  
  -- Полный JSON для гибкости
  full_snapshot JSONB DEFAULT '{}',
  
  refreshed_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_aibs_user ON ai_business_snapshot(user_id);
ALTER TABLE ai_business_snapshot ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "aibs_all" ON ai_business_snapshot;
CREATE POLICY "aibs_all" ON ai_business_snapshot FOR ALL USING (auth.uid() = user_id);
